#!/bin/sh

python preprocessing.py ./stanford-corenlp-full-2014-08-27 ./ollie data/gflowExamples/data1/

export WORDNET_DICT=WordNet-3.0/dict

javac -d bin -cp weka-3-6-12/weka.jar:jaws-bin.jar src/edu/washington/cs/knowitall/datastructures/*.java src/edu/washington/cs/knowitall/main/*.java src/edu/washington/cs/knowitall/summarization/*.java src/edu/washington/cs/knowitall/utilities//*.java

java -cp weka-3-6-12/weka.jar:jaws-bin.jar:bin edu.washington.cs.knowitall.main.GFlow data/gflowExamples/data1

